// --- Variáveis Globais do Jogo ---
let estadoJogo = 0; // 0: introdução, 1: preparando o campo, 2: escolhendo cultura, 3: plantando/regando, 4: crescendo, 5: colhendo, 6: transportando
let culturaSelecionadaParaPlantio = null; // Guarda a cultura escolhida para o próximo plantio
let produtosColhidos = 0;

// --- Variáveis do Jogador ---
let jogadorX, jogadorY;
let jogadorLargura = 40;
let jogadorAltura = 70;
let velocidadeJogador = 3;
let alcanceInteracao = 80; // Distância máxima para o jogador interagir com algo

// --- Variáveis do NPC Guia ---
let npcGuiaX, npcGuiaY;
let npcGuiaLargura = 60;
let npcGuiaAltura = 90;
let textoNpc = ""; // Texto que o NPC exibirá

// --- Arrays de Áreas de Plantio ---
let areasDePlantio = []; // Conterá objetos da classe AreaPlantio

// --- Imagens (você precisará criar ou encontrar imagens simples para isso) ---
let imgAgricultor; // Imagem para o jogador
let imgNpcGuia; // Imagem para o NPC guia
let imgMilho;
let imgCana;
let imgMandioca;
let imgSoja;
let imgTrator; // Ou ferramenta para preparar o campo
let imgRegador;
let imgCaminhao;
let imgCidade; // Fundo para a cidade

// --- Preload: Carrega as imagens antes do setup ---
function preload() {
    // Descomente e substitua os caminhos para suas imagens!
    // imgAgricultor = loadImage('assets/agricultor.png');
    // imgNpcGuia = loadImage('assets/npc_guia.png');
    // imgMilho = loadImage('assets/milho.png');
    // imgCana = loadImage('assets/cana.png');
    // imgMandioca = loadImage('assets/mandioca.png');
    // imgSoja = loadImage('assets/soja.png');
    // imgTrator = loadImage('assets/trator.png');
    // imgRegador = loadImage('assets/regador.png');
    // imgCaminhao = loadImage('assets/caminhao.png');
    // imgCidade = loadImage('assets/cidade.png');
}

// --- Setup: Configurações Iniciais ---
function setup() {
    createCanvas(700, 500); // Tamanho da tela do jogo
    textAlign(CENTER, CENTER);
    textSize(20);

    // Posição inicial do jogador
    jogadorX = width / 2;
    jogadorY = height - jogadorAltura - 20;

    // Posição do NPC Guia
    npcGuiaX = 100;
    npcGuiaY = height - npcGuiaAltura - 20;

    // Inicializa as três áreas de plantio
    for (let i = 0; i < 3; i++) {
        let divisoriaX = 50 + i * (width / 3 - 20 + 20);
        let divisoriaY = height / 2 + 50;
        let divisoriaLargura = width / 3 - 20;
        let divisoriaAltura = height / 2 - 100;
        areasDePlantio.push(new AreaPlantio(divisoriaX, divisoriaY, divisoriaLargura, divisoriaAltura, i));
    }

    // Define o texto inicial do NPC
    textoNpc = "Olá! Seja bem-vindo a Fazenda Chuva Bonita!Clique para começar!";
}

// --- Draw: Loop Principal do Jogo ---
function draw() {
    background(135, 206, 235); // Céu azul

    // Desenha o campo (fundo de terra)
    fill(150, 100, 50); // Cor de terra
    rect(0, height / 2, width, height / 2); // Metade inferior da tela

    // Desenha e atualiza as áreas de plantio
    areasDePlantio.forEach(area => {
        area.desenhar();
        // A lógica de crescimento da planta está na classe Planta
    });

    // Desenha o NPC Guia
    drawNpcGuia();

    // Desenha o Jogador e gerencia seu movimento
    drawJogador();

    // Lógica do jogo baseada no estado
    switch (estadoJogo) {
        case 0: // Introdução
            // O texto do NPC já é definido no setup e no mousePressed
            break;
        case 1: // Preparar Campo
            // O texto do NPC já é definido no mousePressed
            break;
        case 2: // Escolher Cultura
            escolherCulturaUI();
            break;
        case 3: // Plantando/Regando (jogador clica na área)
            // A UI agora é mais implícita, guiada pelo NPC
            break;
        case 4: // Crescimento (plantas crescem automaticamente)
            gerenciarCrescimento();
            break;
        case 5: // Colheita (jogador clica na planta pronta)
            // A UI agora é mais implícita, guiada pelo NPC
            break;
        case 6: // Transporte
            transporteUI();
            break;
    }
}

// --- Classes para Organização do Código ---

// Classe para representar uma planta individual
class Planta {
    constructor(x, y, tipo) {
        this.x = x;
        this.y = y;
        this.tipo = tipo;
        this.progressoCrescimento = 0; // 0 a 100
        this.prontaParaColher = false;
    }

    // Atualiza o crescimento da planta
    crescer() {
        if (this.progressoCrescimento < 100) {
            this.progressoCrescimento += 0.1; // Velocidade de crescimento
            if (this.progressoCrescimento >= 100) {
                this.progressoCrescimento = 100;
                this.prontaParaColher = true;
            }
        }
    }

    // Desenha a planta na tela
    desenhar() {
        let tamanhoBase = 20;
        let tamanhoAtual = tamanhoBase + (tamanhoBase * this.progressoCrescimento / 100);

        fill(0, 150, 0); // Cor da planta
        if (this.tipo === "Milho") {
            // Exemplo de desenho mais detalhado
            rect(this.x - tamanhoAtual / 4, this.y - tamanhoAtual, tamanhoAtual / 2, tamanhoAtual);
            ellipse(this.x, this.y - tamanhoAtual - 5, tamanhoAtual / 2, tamanhoAtual / 3); // Topo
            // if (imgMilho && this.prontaParaColher) image(imgMilho, this.x - tamanhoAtual / 2, this.y - tamanhoAtual, tamanhoAtual, tamanhoAtual);
        } else if (this.tipo === "Cana") {
            rect(this.x - tamanhoAtual / 8, this.y - tamanhoAtual, tamanhoAtual / 4, tamanhoAtual);
            // if (imgCana && this.prontaParaColher) image(imgCana, this.x - tamanhoAtual / 2, this.y - tamanhoAtual, tamanhoAtual, tamanhoAtual);
        } else if (this.tipo === "Mandioca") {
            ellipse(this.x, this.y, tamanhoAtual, tamanhoAtual / 2); // Representação de raiz
            // if (imgMandioca && this.prontaParaColher) image(imgMandioca, this.x - tamanhoAtual / 2, this.y - tamanhoAtual, tamanhoAtual, tamanhoAtual);
        } else if (this.tipo === "Soja") {
            ellipse(this.x, this.y - tamanhoAtual / 2, tamanhoAtual / 2, tamanhoAtual / 2); // Representação de arbusto
            // if (imgSoja && this.prontaParaColher) image(imgSoja, this.x - tamanhoAtual / 2, this.y - tamanhoAtual, tamanhoAtual, tamanhoAtual);
        }

        // Desenha barra de progresso individual se ainda não estiver pronta
        if (this.progressoCrescimento < 100) {
            fill(0, 200, 0);
            rect(this.x - 15, this.y + 5, 30 * (this.progressoCrescimento / 100), 5);
            noFill();
            stroke(255);
            rect(this.x - 15, this.y + 5, 30, 5);
            noStroke();
        }
    }
}

// Classe para representar uma área de plantio (lote)
class AreaPlantio {
    constructor(x, y, largura, altura, id) {
        this.x = x;
        this.y = y;
        this.largura = largura;
        this.altura = altura;
        this.id = id; // Para identificar a área (0, 1, 2)
        this.plantas = []; // Array de objetos Planta
        this.preparado = false; // Indica se a terra foi preparada
    }

    // Desenha a área de plantio
    desenhar() {
        stroke(255); // Borda branca
        strokeWeight(2);
        // Destaca a área se o jogador estiver perto dela e for interativa
        let jogadorPerto = dist(jogadorX, jogadorY, this.x + this.largura / 2, this.y + this.altura / 2) < alcanceInteracao + 50; // Aumenta um pouco o alcance para destaque visual

        if (jogadorPerto && (estadoJogo === 3 || estadoJogo === 5)) { // Se estiver nos estados de plantio/rega ou colheita
             fill(200, 150, 100); // Cor mais clara para área ativa/interagível
        } else if (this.preparado) {
            fill(120, 80, 30); // Cor normal para área preparada
        } else {
            fill(80, 50, 10); // Cor mais escura se não estiver preparada
        }
        rect(this.x, this.y, this.largura, this.altura, 10); // Borda arredondada
        noStroke();

        // Desenha todas as plantas dentro desta área
        this.plantas.forEach(planta => {
            planta.desenhar();
        });

        // Mostra o ID da área (para depuração ou orientação)
        fill(255);
        textSize(16);
        text(`Área ${this.id + 1}`, this.x + this.largura / 2, this.y + 20);
        textSize(20); // Volta ao tamanho padrão
    }

    // Adiciona uma nova planta na área
    // Calcula uma posição aleatória dentro da área para simular mais plantações
    adicionarPlanta(tipo) {
        let novaPlantaX = this.x + random(20, this.largura - 20);
        let novaPlantaY = this.y + random(this.altura * 0.4, this.altura - 20); // Planta mais na parte inferior da área
        this.plantas.push(new Planta(novaPlantaX, novaPlantaY, tipo));
    }

    // Colhe uma planta específica (se estiver pronta)
    colherPlanta(plantaClicada) {
        const index = this.plantas.indexOf(plantaClicada);
        if (index > -1 && plantaClicada.prontaParaColher) {
            this.plantas.splice(index, 1); // Remove a planta
            produtosColhidos++;
            return true;
        }
        return false;
    }
}

// --- Funções de Desenho dos Personagens ---

function drawNpcGuia() {
    fill(0, 100, 200); // Cor do corpo do NPC
    ellipse(npcGuiaX, npcGuiaY, npcGuiaLargura, npcGuiaAltura);
    fill(255, 200, 150); // Cor do rosto
    ellipse(npcGuiaX, npcGuiaY - npcGuiaAltura / 2.5, npcGuiaLargura * 0.7, npcGuiaLargura * 0.7);
    // if (imgNpcGuia) image(imgNpcGuia, npcGuiaX - npcGuiaLargura / 2, npcGuiaY - npcGuiaAltura / 2, npcGuiaLargura, npcGuiaAltura);

    // Balão de fala do NPC
    fill(255);
    rect(npcGuiaX + 30, npcGuiaY - npcGuiaAltura - 100, 255, 110, 10); // Balão
    triangle(npcGuiaX + 20, npcGuiaY - npcGuiaAltura - 5,
             npcGuiaX + 40, npcGuiaY - npcGuiaAltura - 50,
             npcGuiaX + 40, npcGuiaY - npcGuiaAltura - 5); // Ponta do balão
    fill(0);
    text(textoNpc, npcGuiaX + 30 +5, npcGuiaY - npcGuiaAltura - 130 + 50, 240, 90); // Texto dentro do balão
}

function drawJogador() {
    // Movimento do jogador com WASD
    if (keyIsDown(87)) { // W - cima
        jogadorY -= velocidadeJogador;
    }
    if (keyIsDown(83)) { // S - baixo
        jogadorY += velocidadeJogador;
    }
    if (keyIsDown(65)) { // A - esquerda
        jogadorX -= velocidadeJogador;
    }
    if (keyIsDown(68)) { // D - direita
        jogadorX += velocidadeJogador;
    }

    // Limita o jogador dentro da tela e da área do campo
    jogadorX = constrain(jogadorX, jogadorLargura / 2, width - jogadorLargura / 2);
    jogadorY = constrain(jogadorY, height / 2 + 50 + jogadorAltura / 2, height - jogadorAltura / 2);

    fill(0, 50, 0); // Cor do corpo do jogador
    rect(jogadorX - jogadorLargura / 2, jogadorY - jogadorAltura / 2, jogadorLargura, jogadorAltura);
    fill(255, 200, 150); // Cor do rosto
    ellipse(jogadorX, jogadorY - jogadorAltura / 2.5, jogadorLargura * 0.7, jogadorLargura * 0.7);
    // if (imgAgricultor) image(imgAgricultor, jogadorX - jogadorLargura / 2, jogadorY - jogadorAltura / 2, jogadorLargura, jogadorAltura);
}

// --- Funções de UI para cada estado do jogo ---

function escolherCulturaUI() {
    // Desenha os botões de escolha de cultura na parte superior da tela
    fill(0, 100, 0);
    rect(width / 4 - 50, 50, 100, 50); // Milho
    fill(255);
    text("Milho", width / 4, 50 + 25);

    fill(0, 100, 0);
    rect(width / 2 - 50, 50, 100, 50); // Cana
    fill(255);
    text("Cana", width / 2, 50 + 25);

    fill(0, 100, 0);
    rect(width * 3 / 4 - 50, 50, 100, 50); // Mandioca
    fill(255);
    text("Mandioca", width * 3 / 4, 50 + 25);

    fill(0, 100, 0);
    rect(width / 2 - 50, 120, 100, 50); // Soja
    fill(255);
    text("Soja", width / 2, 120 + 25);
}

function gerenciarCrescimento() {
    // Itera sobre todas as áreas e suas plantas para fazer crescer
    let plantasProntasParaColher = 0;
    areasDePlantio.forEach(area => {
        area.plantas.forEach(planta => {
            planta.crescer();
            if (planta.prontaParaColher) {
                plantasProntasParaColher++;
            }
        });
    });

    if (plantasProntasParaColher > 0) {
        textoNpc = `Algumas plantas estão prontas para colher! Vá até elas e clique para colher.`;
        estadoJogo = 5; // Mude para o estado de colheita quando houver algo para colher
    } else {
         textoNpc = `As plantas estão crescendo... Aguarde e observe o progresso!`;
    }
}

function transporteUI() {
    background(imgCidade ? imgCidade : 150, 150, 200); // Fundo da cidade ou cor clara
    fill(255);
    text(`Transportando ${produtosColhidos} produtos para a cidade/indústria!`, width / 2, height / 3);
    text("Obrigado por ajudar a alimentar o mundo!", width / 2, height / 2);

    // Adicionar animação de caminhão aqui se tiver a imagem
    // if (imgCaminhao) image(imgCaminhao, width / 2 - 100, height * 0.7, 200, 100);

    // Texto de "clique para reiniciar"
    fill(0, 150, 0);
    rect(width / 2 - 100, height * 0.8, 200, 50);
    fill(255);
    text("Reiniciar Jogo", width / 2, height * 0.8 + 25);
}


// --- Eventos de Mouse ---
function mousePressed() {
    switch (estadoJogo) {
        case 0: // Introdução
            estadoJogo = 1;
            textoNpc = "Muito bem! O primeiro passo é preparar a terra para o plantio. Clique para continuar!";
            break;
        case 1: // Preparar Campo
            areasDePlantio.forEach(area => area.preparado = true);
            estadoJogo = 2;
            textoNpc = "As terras estão prontas! Agora, escolha qual cultura plantar e clique em uma área para plantar!";
            break;
        case 2: // Escolher Cultura (clique nos botões de cultura e depois na área)
            // Lógica para detectar clique nos botões de cultura (na parte superior da tela)
            if (mouseY < height / 2) { // Se o clique foi na metade superior da tela (onde estão os botões)
                if (mouseX > width / 4 - 50 && mouseX < width / 4 + 50 && mouseY > 50 && mouseY < 100) {
                    culturaSelecionadaParaPlantio = "Milho";
                    textoNpc = "Você escolheu Milho. Agora vá até uma área de plantio e clique para plantar!";
                } else if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50 && mouseY > 50 && mouseY < 100) {
                    culturaSelecionadaParaPlantio = "Cana";
                    textoNpc = "Você escolheu Cana. Agora vá até uma área de plantio e clique para plantar!";
                } else if (mouseX > width * 3 / 4 - 50 && mouseX < width * 3 / 4 + 50 && mouseY > 50 && mouseY < 100) {
                    culturaSelecionadaParaPlantio = "Mandioca";
                    textoNpc = "Você escolheu Mandioca. Agora vá até uma área de plantio e clique para plantar!";
                } else if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50 && mouseY > 120 && mouseY < 170) {
                    culturaSelecionadaParaPlantio = "Soja";
                    textoNpc = "Você escolheu Soja. Agora vá até uma área de plantio e clique para plantar!";
                }
            } else { // Se o clique foi na parte inferior da tela (nas áreas de plantio)
                if (culturaSelecionadaParaPlantio !== null) {
                    let plantou = false;
                    areasDePlantio.forEach(area => {
                        // Verifica se o jogador está perto E se o clique foi dentro da área
                        if (dist(jogadorX, jogadorY, area.x + area.largura / 2, area.y + area.altura / 2) < alcanceInteracao &&
                            mouseX > area.x && mouseX < area.x + area.largura &&
                            mouseY > area.y && mouseY < area.y + area.altura &&
                            area.preparado) {
                            area.adicionarPlanta(culturaSelecionadaParaPlantio);
                            plantou = true;
                            textoNpc = `Você plantou ${culturaSelecionadaParaPlantio} na área ${area.id + 1}! Plante mais ou clique em outra área.`;
                            // estadoJogo = 3; // Mantém no estado 2 para permitir plantar mais
                        }
                    });
                    if (plantou) {
                        estadoJogo = 3; // Transiciona para plantando/regando
                    } else {
                        textoNpc = "Você precisa estar perto de uma área preparada para plantar!";
                    }
                } else {
                    textoNpc = "Selecione uma cultura primeiro antes de clicar na área de plantio!";
                }
            }
            break;
        case 3: // Plantando/Regando (jogador pode continuar plantando ou mudar para crescimento)
            if (mouseY < height / 2) { // Permite escolher outra cultura se clicar nos botões de cima
                // Permite mudar a cultura selecionada
                if (mouseX > width / 4 - 50 && mouseX < width / 4 + 50 && mouseY > 50 && mouseY < 100) {
                    culturaSelecionadaParaPlantio = "Milho";
                    textoNpc = "Você escolheu Milho. Vá até uma área de plantio e clique para plantar!";
                } else if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50 && mouseY > 50 && mouseY < 100) {
                    culturaSelecionadaParaPlantio = "Cana";
                    textoNpc = "Você escolheu Cana. Vá até uma área de plantio e clique para plantar!";
                } else if (mouseX > width * 3 / 4 - 50 && mouseX < width * 3 / 4 + 50 && mouseY > 50 && mouseY < 100) {
                    culturaSelecionadaParaPlantio = "Mandioca";
                    textoNpc = "Você escolheu Mandioca. Vá até uma área de plantio e clique para plantar!";
                } else if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50 && mouseY > 120 && mouseY < 170) {
                    culturaSelecionadaParaPlantio = "Soja";
                    textoNpc = "Você escolheu Soja. Vá até uma área de plantio e clique para plantar!";
                }
            } else { // Se o clique foi na parte inferior da tela (nas áreas de plantio ou para avançar)
                let plantouMais = false;
                if (culturaSelecionadaParaPlantio !== null) {
                    areasDePlantio.forEach(area => {
                        // Verifica se o jogador está perto E se o clique foi dentro da área
                        if (dist(jogadorX, jogadorY, area.x + area.largura / 2, area.y + area.altura / 2) < alcanceInteracao &&
                            mouseX > area.x && mouseX < area.x + area.largura &&
                            mouseY > area.y && mouseY < area.y + area.altura &&
                            area.preparado) {
                            area.adicionarPlanta(culturaSelecionadaParaPlantio);
                            plantouMais = true;
                            textoNpc = `Você plantou mais ${culturaSelecionadaParaPlantio} na área ${area.id + 1}! Plante mais ou clique fora para ver crescer.`;
                        }
                    });
                }

                if (!plantouMais) {
                    estadoJogo = 4; // Mudar para o estado de crescimento se não plantou mais nada
                    textoNpc = "As plantas estão crescendo... Aguarde e observe o progresso!";
                } else {
                     textoNpc = "Você precisa estar perto de uma área preparada para plantar!";
                }
            }
            break;
        case 4: // Crescimento (não há clique de interação para avançar, é automático)
            // O jogador pode clicar em qualquer lugar para "chamar" o NPC
            textoNpc = "As plantas estão crescendo... Use WASD para se movimentar pelo campo.";
            break;
        case 5: // Colheita (clique nas plantas prontas)
            let algumaCoisaColhida = false;
            let temPlantasParaColher = false; // Flag para verificar se há alguma planta pronta
            areasDePlantio.forEach(area => {
                area.plantas.forEach(planta => {
                    if (planta.prontaParaColher) {
                        temPlantasParaColher = true;
                    }
                    // Verifica se o clique foi na planta E se o jogador está perto da planta
                    if (dist(jogadorX, jogadorY, planta.x, planta.y) < alcanceInteracao &&
                        dist(mouseX, mouseY, planta.x, planta.y) < 25) { // Clicou perto da planta
                        if (area.colherPlanta(planta)) {
                            algumaCoisaColhida = true;
                        }
                    }
                });
            });

            if (algumaCoisaColhida) {
                // Atualiza o texto após colher
                textoNpc = `Você colheu! Total colhido: ${produtosColhidos}. Continue colhendo ou clique no caminhão para transportar.`;
            } else {
                let todasColhidas = true;
                areasDePlantio.forEach(area => {
                    area.plantas.forEach(planta => {
                        if (planta.prontaParaColher) { // Verifica se ainda tem plantas prontas
                            todasColhidas = false;
                        }
                    });
                });

                if (todasColhidas && produtosColhidos > 0) { // Se não tem mais plantas prontas e já colheu algo
                    estadoJogo = 6;
                    textoNpc = `Todos os produtos foram colhidos! Agora vamos para o transporte.`;
                } else if (!temPlantasParaColher && produtosColhidos > 0) {
                     // Se todas já foram colhidas, mas o jogo ainda está no estado 5
                     estadoJogo = 6;
                     textoNpc = `Todos os produtos foram colhidos! Agora vamos para o transporte.`;
                }
                else {
                    textoNpc = "Clique nas plantas maduras para colher! Lembre-se de estar perto com seu personagem.";
                }
            }
            break;
        case 6: // Transporte (clique no botão de reiniciar)
            if (mouseX > width / 2 - 100 && mouseX < width / 2 + 100 && mouseY > height * 0.8 && mouseY < height * 0.8 + 50) {
                // Reinicia o jogo
                estadoJogo = 0;
                culturaSelecionadaParaPlantio = null;
                produtosColhidos = 0;
                areasDePlantio.forEach(area => {
                    area.plantas = []; // Limpa as plantas de todas as áreas
                    area.preparado = false;
                });
                textoNpc = "Olá! Seja bem-vindo a Fazenda Chuva Bonita!Clique para começar!";
            }
            break;
    }
}